while :
do
    python3 BrainWallet.py
done
